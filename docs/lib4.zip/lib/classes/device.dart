class Device {
  int date;
  String month, year;
  double income, expense;

  Device({this.date, this.month, this.year, this.income, this.expense});
}
