import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

enum TransType { expense, income }

class AddTransaction extends StatefulWidget {
  @override
  _AddTransactionState createState() => _AddTransactionState();
}

class _AddTransactionState extends State<AddTransaction> {
  var _formKey = GlobalKey<FormState>();
  final _formFieldKey = GlobalKey<FormFieldState>();
  final _formFieldKey1 = GlobalKey<FormFieldState>();
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  TransType suit = TransType.expense;

  List<String> category_list = ['Food', 'Social Life', 'Transportation'];
  String category;

  List<String> currency_list = ['PKR', 'USD', 'EURO'];
  String currency;

  var amount;
  var note;

  TextEditingController amountControl = TextEditingController();
  TextEditingController catControl = TextEditingController();

  DateTime selectedDate = DateTime.now();
  String f_date = new DateFormat.yMMMd().format(DateTime.now());

  @override
  Widget build(BuildContext context) {
    return (new Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text("Transaction"),
        backgroundColor: Colors.orange,
      ),
      body: Form(
        key: _formKey,
        child: Padding(
          padding: EdgeInsets.all(10.0),
          child: ListView(children: <Widget>[
            Container(
                padding: EdgeInsets.all(10.0),
                child: Row(
                  children: <Widget>[
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 100, 0),
                      child: Text(
                        "Date",
                        style: TextStyle(fontSize: 19),
                      ),
                    ),
                    Material(
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5),
                          side: BorderSide(color: Colors.orangeAccent)),
                      child: Container(
                          alignment: Alignment.center,
                          height: 50,
                          width: MediaQuery.of(context).size.width / 2.3,
                          padding: EdgeInsets.only(left: 10, right: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              InkWell(
                                onTap: () {
                                  showDatePicker(
                                    context: context,
                                    initialDate: selectedDate,
                                    firstDate: DateTime(2000),
                                    lastDate: DateTime(2120),
                                  ).then((date) {
                                    setState(() {
                                      selectedDate = date;
                                      f_date = new DateFormat.yMMMd()
                                          .format(selectedDate);
                                    });
                                  });
                                },
                                child: Row(children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                                    child: Text(
                                      '$f_date',
                                      style: TextStyle(fontSize: 17),
                                    ),
                                  ),
                                  Icon(
                                    Icons.date_range,
                                    size: 25,
                                    color: Colors.orange,
                                  ),
                                ]),
                              )
                            ],
                          )),
                    ),
                  ],
                )),
            Container(
              padding: EdgeInsets.all(10.0),
              child: Row(children: <Widget>[
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 40, 0),
                  child: Text(
                    "Type",
                    style: TextStyle(fontSize: 19),
                  ),
                ),
                Radio(
                    value: TransType.expense,
                    groupValue: suit,
                    activeColor: Colors.orange,
                    onChanged: (TransType value) {
                      setState(() {
                        suit = value;
                      });
                    }),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                  child: Text(
                    "Expense",
                    style: TextStyle(fontSize: 17),
                  ),
                ),
                Radio(
                    value: TransType.income,
                    groupValue: suit,
                    onChanged: (TransType value) {
                      setState(() {
                        suit = value;
                      });
                    }),
                Text(
                  "Income",
                  style: TextStyle(fontSize: 17),
                ),
              ]),
            ),
            Container(
              padding: EdgeInsets.all(10.0),
              child: Row(children: <Widget>[
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 60, 0),
                  child: Text(
                    "Category",
                    style: TextStyle(fontSize: 19),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Material(
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5),
                          side: BorderSide(color: Colors.orangeAccent)),
                      child: Container(
                        alignment: Alignment.center,
                        height: 50,
                        width: MediaQuery.of(context).size.width / 2.3,
                        child: DropdownButtonFormField(
                          value: this.category,
                          onChanged: (val) => this.category = val,
                          onSaved: (val) => this.category = val,
                          items: category_list
                              .map((val) => DropdownMenuItem(
                                    value: val,
                                    child: Text(val),
                                  ))
                              .toList(),
                          isExpanded: true,
                          // makes the dropdown of it's parent size. e.g: Container
                          decoration: InputDecoration(
                              border: InputBorder.none,
                              isDense: true,
                              hintText: 'Select',
                              labelStyle:
                                  TextStyle(fontSize: 17, color: Colors.grey),
                              filled: true,
                              fillColor: Colors.white70),
                          isDense: true,
                          icon: Icon(
                            Icons.keyboard_arrow_down,
                            color: Colors.orange,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
              ]),
            ),
            Container(
              padding: EdgeInsets.all(10.0),
              child: Row(children: <Widget>[
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 60, 0),
                  child: Text(
                    "Currency",
                    style: TextStyle(fontSize: 19),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Material(
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5),
                          side: BorderSide(color: Colors.orangeAccent)),
                      child: Container(
                        alignment: Alignment.center,
                        height: 50,
                        width: MediaQuery.of(context).size.width / 2.3,
                        child: DropdownButtonFormField(
                          value: this.currency,
                          onChanged: (val) => this.currency = val,
                          onSaved: (val) => this.currency = val,
                          items: currency_list
                              .map((val) => DropdownMenuItem(
                                    value: val,
                                    child: Text(val),
                                  ))
                              .toList(),
                          isExpanded: true,
                          // makes the dropdown of it's parent size. e.g: Container
                          decoration: InputDecoration(
                              border: InputBorder.none,
                              isDense: true,
                              hintText: 'Select',
                              labelStyle:
                                  TextStyle(fontSize: 17, color: Colors.grey),
                              filled: true,
                              fillColor: Colors.white70),
                          isDense: true,
                          icon: Icon(
                            Icons.keyboard_arrow_down,
                            color: Colors.orange,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
              ]),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(10, 30, 0, 0),
              child: Text(
                "Amount",
                style: TextStyle(fontSize: 19),
              ),
            ),
            SizedBox(
              height: 18,
            ),
            TextFormField(
              key: _formFieldKey1,
              onSaved: (val) {
                this.amount = val;
              },
              validator: (val) {
                if (val.isEmpty) {
                  return 'Amount cannot be empty.';
                } else {
                  return null;
                }
              },
              keyboardType: TextInputType.number,
              autovalidateMode: AutovalidateMode.onUserInteraction,
              decoration: InputDecoration(
                prefixIcon: Icon(
                  Icons.attach_money_sharp,
                  color: Colors.orange,
                ),
                hintText: 'Enter Amount',
                focusColor: Colors.orange,
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(color: Colors.orange)),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(color: Colors.orange)),
                focusedErrorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(color: Colors.red)),
                errorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(color: Colors.red)),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(10, 30, 0, 0),
              child: Text(
                "Note",
                style: TextStyle(fontSize: 19),
              ),
            ),
            SizedBox(
              height: 18,
            ),
            TextFormField(
              key: _formFieldKey,
              onSaved: (val) {
                this.note = val;
              },
              autovalidateMode: AutovalidateMode.onUserInteraction,
              decoration: InputDecoration(
                prefixIcon: Icon(
                  Icons.note_add,
                  color: Colors.orange,
                ),
                hintText: 'Enter Note',
                focusColor: Colors.orange,
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(color: Colors.orange)),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(color: Colors.orange)),
                focusedErrorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(color: Colors.red)),
                errorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(color: Colors.red)),
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Container(
              margin: EdgeInsets.only(top: 20),
              child: MaterialButton(
                minWidth: MediaQuery.of(context).size.width,
                height: 50,
                visualDensity: VisualDensity.adaptivePlatformDensity,
                elevation: 1,
                splashColor: Colors.orangeAccent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(9),
                    side: BorderSide(color: Colors.orangeAccent)),
                onPressed: () {
                  if (_formFieldKey.currentState.validate() &&
                      this.category != null &&
                      this.currency != null) {
                    showAlertDialog(context);
                  } else {
                    _scaffoldKey.currentState.showSnackBar(SnackBar(
                        content: Text(
                            'Category, Currency or Amount might be empty.')));
                  }
                },
                color: Colors.orange,
                child: Text(
                  'Save Changes',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ]),
        ),
      ),
    ));
  }
}

void showAlertDialog(BuildContext context) {
  // set up the buttons
  Widget cancelButton = FlatButton(
    child: Text("Cancel"),
    onPressed: () {
      Navigator.of(context, rootNavigator: true).pop();
    },
  );
  Widget continueButton = FlatButton(
    child: Text("Save"),
    onPressed: () {
      Navigator.of(context, rootNavigator: true).pop();
      Navigator.of(context).pop();
    },
  ); // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("CONFIRMATION"),
    content: Text("Would you like to save your transactions details?"),
    actions: [
      cancelButton,
      continueButton,
    ],
  ); // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}
